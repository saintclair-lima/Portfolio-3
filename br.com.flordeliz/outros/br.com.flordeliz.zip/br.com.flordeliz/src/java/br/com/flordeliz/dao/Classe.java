/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.flordeliz.dao;

import br.com.flordeliz.controlador.ControleLote;
import br.com.flordeliz.controlador.ControlePedido;
import br.com.flordeliz.modelo.Cliente;
import br.com.flordeliz.modelo.EntidadeNulaException;
import br.com.flordeliz.modelo.Entrega;
import br.com.flordeliz.modelo.InsercaoException;
import br.com.flordeliz.modelo.ItemEntrega;
import br.com.flordeliz.modelo.ItemEstoque;
import br.com.flordeliz.modelo.ItemPedido;
import br.com.flordeliz.modelo.Pedido;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author saintclair
 */
public class Classe {
    
    final String usuario = "postgres";
    final String senha = "";
    final String endereco = "localhost/liz";
    
    public void insert() throws EntidadeNulaException, InsercaoException{
        ClienteDAO clienteDAO = new ClienteDAO();
        ItemEstoqueDAO itemEstoqueDAO = new ItemEstoqueDAO();
        Cliente cliente = clienteDAO.buscar(this.usuario, this.senha, this.endereco, 10);
        
        Pedido pedido = new Pedido(0,1,cliente);
        Entrega entrega = new Entrega(0, Entrega.PENDENTE);
        pedido.setEntrega(entrega);
        
        ItemEstoque itemEstoque1 = itemEstoqueDAO.buscar(this.usuario, this.senha, this.endereco, 1);
        ItemEstoque itemEstoque2 = itemEstoqueDAO.buscar(this.usuario, this.senha, this.endereco, 2);
        ItemEstoque itemEstoque3 = itemEstoqueDAO.buscar(this.usuario, this.senha, this.endereco, 3);
        
        ItemPedido itemPedido1 = new ItemPedido(1, 1, itemEstoque1);
        pedido.inserirItem(itemPedido1);
        ItemPedido itemPedido2 = new ItemPedido(2, 2, itemEstoque2);
        pedido.inserirItem(itemPedido2);
        ItemPedido itemPedido3 = new ItemPedido(3, 3, itemEstoque3);
        pedido.inserirItem(itemPedido3);
        
        ItemEntrega itemEntrega1 = new ItemEntrega(1, 1, itemEstoque1);
        entrega.inserirItem(itemEntrega1);
        ItemEntrega itemEntrega2 = new ItemEntrega(2, 2, itemEstoque2);
        entrega.inserirItem(itemEntrega2);
        ItemEntrega itemEntrega3 = new ItemEntrega(3, 3, itemEstoque3);
        entrega.inserirItem(itemEntrega3);
        
        pedido.setEntrega(entrega);
        
        PedidoDAO pedidoDAO = new PedidoDAO();
        pedidoDAO.inserir(usuario, senha, endereco, pedido);
    }
    
    public int inserirPedido() {
        ClienteDAO clienteDAO = new ClienteDAO();
        ItemEstoqueDAO itemEstoqueDAO = new ItemEstoqueDAO();
        PedidoDAO pedidoDAO = new PedidoDAO();
        Pedido pedido;
        Entrega entrega;
        Cliente cliente = null;
        int resultadoOperacao = 0;
        
        int clienteCodigo = 7;
        String [] listaItemEstoqueCodigos = {"1","2","3"};
        String [] quantidadesItens = {"100", "157", "200"};
        
        
        try {
            cliente = clienteDAO.buscar(this.usuario, this.senha, this.endereco, clienteCodigo);
        
        
            pedido = new Pedido(0,1,cliente);
            entrega = new Entrega(0, Entrega.PENDENTE);
            pedido.setEntrega(entrega);

            int indiceItens = 0;
            for (String codigo : listaItemEstoqueCodigos){
                ItemEstoque itemEstoque = itemEstoqueDAO.buscar(this.usuario, this.senha, this.endereco, Integer.parseInt(codigo));
                
                int quantidadeItemAtual = Integer.parseInt(quantidadesItens[indiceItens]);
                
                ItemPedido itemPedido = new ItemPedido(indiceItens + 1, quantidadeItemAtual, itemEstoque);
                
                ItemEntrega itemEntrega = new ItemEntrega(indiceItens + 1, quantidadeItemAtual, itemEstoque);
                
                pedido.inserirItem(itemPedido);
                
                pedido.getEntrega().inserirItem(itemEntrega);
                
                indiceItens ++;
            }

            resultadoOperacao = pedidoDAO.inserir(usuario, senha, endereco, pedido);
            return resultadoOperacao;
        
        } catch (EntidadeNulaException ex) {
            Logger.getLogger(ControlePedido.class.getName()).log(Level.SEVERE, null, ex);
            /*TODO Considerar Criar indicativo de Entidade nula ERRO_NULL_EXCEPTION
            */
            
            Logger.getLogger("Entidade Nula Exception", ControleLote.class.getName());
            return PedidoDAO.ERRO_INSERCAO;
            
        } catch (InsercaoException ex) {
            //System.out.print("Insercao Exception");
            Logger.getLogger("Insercao Exception", ControleLote.class.getName());
            
            return PedidoDAO.ERRO_INSERCAO;
        }
    }
}
