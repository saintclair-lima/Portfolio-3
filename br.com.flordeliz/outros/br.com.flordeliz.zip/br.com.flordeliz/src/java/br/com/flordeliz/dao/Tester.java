package br.com.flordeliz.dao;
// *
// * @author saintclair

import br.com.flordeliz.modelo.EntidadeNulaException;
import br.com.flordeliz.modelo.InsercaoException;


public class Tester {
    final String usuario = "postgres";
    final String senha = "";
    final String endereco = "localhost/liz";
    

    public static void main (String args[]) throws EntidadeNulaException, InsercaoException {
        Classe c = new Classe();
        c.inserirPedido();
    }
}
